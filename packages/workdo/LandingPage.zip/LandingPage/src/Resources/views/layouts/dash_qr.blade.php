<div class="col-md-3 col-12">
    <div class="qr-card">
        <div class="qr-card-inner">
            <div class="shareqrcode"></div>
            <div class="qr-card-content">
                <div class="qr-btn">
                    <span>{{__('Landingpage')}}</span>
                    <a href="javascript:" tabindex="0" class="cp_link" data-link="{{ url('/') }}" data-bs-toggle="tooltip" data-bs-placement="top"
                    title="" data-bs-original-title="Click to copy site link">
                        <i class="ti ti-layers-linked text-primary"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>