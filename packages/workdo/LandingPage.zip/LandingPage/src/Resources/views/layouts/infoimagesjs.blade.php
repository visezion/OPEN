<script src="{{ asset('packages/workdo/LandingPage/src/Resources/assets/assets/swiper/dist/js/swiper.min.js')}}"></script>
<script src="{{ asset('packages/workdo/LandingPage/src/Resources/assets/assets/previewlinksBlog.js') }}"></script>
<script src="{{ asset('packages/workdo/LandingPage/src/Resources/assets/custom/custom.js') }}"></script>

