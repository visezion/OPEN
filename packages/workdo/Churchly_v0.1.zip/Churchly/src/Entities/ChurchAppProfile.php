<?php

namespace Workdo\Churchly\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ChurchAppProfile extends Model
{
    use HasFactory;

    protected $table = 'church_app_profiles';

    protected $fillable = [
        'workspace_id','app_name','bundle_id_android','bundle_id_ios',
        'primary_color','accent_color','theme_mode','logo_path','splash_path','icon_path',
        'status','is_published','created_by','updated_by'
    ];

    public function scopeForWorkspace($query)
    {
        return $query->where('workspace_id', getActiveWorkSpace());
    }

    public function features()
    {
        return $this->hasMany(ChurchAppFeature::class, 'workspace_id', 'workspace_id');
    }

    public function menuItems()
    {
        return $this->hasMany(ChurchAppMenuItem::class, 'workspace_id', 'workspace_id')
                    ->orderBy('sort_order');
    }

    public function publishSettings()
    {
        return $this->hasOne(ChurchAppPublishSetting::class, 'workspace_id', 'workspace_id');
    }
}
