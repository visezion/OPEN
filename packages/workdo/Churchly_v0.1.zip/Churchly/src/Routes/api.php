<?php

use Illuminate\Support\Facades\Route;
use Workdo\Churchly\Http\Controllers\Api\AppConfigController;
use App\Models\WorkSpace;

Route::get('/churches', function () {
    return WorkSpace::select('id','name','short_code')->where('status','active')->get();
});

Route::get('/church/{workspace}/config', [AppConfigController::class, 'show']);
