<?php

namespace Workdo\Churchly\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Workdo\Churchly\Services\AppConfigGenerator;
use Illuminate\Http\JsonResponse;

class AppConfigController extends Controller
{
    public function show($workspaceId): JsonResponse
    {
        $config = AppConfigGenerator::generate($workspaceId);
        if(!$config) {
            return response()->json(['error' => 'Workspace not found'], 404);
        }
        return response()->json($config);
    }
}
