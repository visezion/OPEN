<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('church_app_profiles', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('workspace_id');
            $table->string('app_name', 191);
            $table->string('bundle_id_android', 191)->nullable();
            $table->string('bundle_id_ios', 191)->nullable();
            $table->string('primary_color', 20)->default('#4A6CF7');
            $table->string('accent_color', 20)->default('#F9B200');
            $table->enum('theme_mode', ['light','dark','system'])->default('system');
            $table->string('logo_path')->nullable();
            $table->string('splash_path')->nullable();
            $table->string('icon_path')->nullable();
            $table->enum('status', ['draft','ready','disabled'])->default('draft');
            $table->boolean('is_published')->default(false);
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();

            $table->unique('workspace_id');
            $table->foreign('workspace_id')->references('id')->on('work_spaces')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('church_app_profiles');
    }
};
