<?php

use Illuminate\Support\Facades\Route;
use Workdo\Churchly\Http\Controllers\Api\AppConfigController;
use App\Models\WorkSpace;
use Workdo\Churchly\Http\Controllers\Api\V1\AuthApiController;
use Workdo\Churchly\Http\Controllers\Api\V1\MemberApiController;
use Workdo\Churchly\Http\Controllers\Api\V1\ChurchAppBuilderController;



Route::prefix('api/v1/churchly')->group(function () {
    Route::get('/churches', function () {
        return WorkSpace::select('id','name','short_code')->where('status','active')->get();
    });

    Route::get('/church/{workspace}/config', [AppConfigController::class, 'show']);


    // 🔑 Authentication (no token needed)
    Route::post('/login', [AuthApiController::class, 'login']);

    // 👥 Member management (token required)
    Route::middleware('auth:sanctum')->group(function () {
        Route::post('/logout', [AuthApiController::class, 'logout']);
        Route::apiResource('/members', MemberApiController::class);
        Route::put('/member/profile', [MemberApiController::class, 'updateProfile']);
    });

    
});
