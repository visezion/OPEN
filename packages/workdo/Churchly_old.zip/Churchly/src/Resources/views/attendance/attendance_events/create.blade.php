@extends('layouts.main')

@section('page-title', __('Setup Attendance Event'))
@section('page-action')
     <a href="{{ route('churchly.events.index') }}" class="btn btn-sm btn-primary">
        <i class="ti ti-eye"></i> View All Events
    </a>    
    <a href="{{ route('churchly.attendance_events.index') }}" class="btn btn-sm btn-primary">
        <i class="ti ti-eye"></i> View All Attendance Events
    </a>
@endsection

@section('content')
<div class="row">
    <!-- Left Column: Form -->
    <div class="col-md-8">
        <div class="card shadow-sm p-4">
            <form method="POST" action="{{ route('churchly.attendance_events.store') }}">
                @csrf
                <div class="mb-3">
                    <label class="form-label">{{ __('Select Event') }}</label>
                    <select name="event_id" class="form-control" required>
                        @foreach($events as $event)
                            <option value="{{ $event->id }}">{{ $event->title }} ({{ $event->date }})</option>
                        @endforeach
                    </select>
                </div>

                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">{{ __('Mode') }}</label>
                        <select name="mode" class="form-control">
                            <option value="onsite">Onsite</option>
                            <option value="online">Online</option>
                            <option value="hybrid">Hybrid</option>
                        </select>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">{{ __('Enabled Methods') }}</label>

                    <div class="form-check">
                        <input type="checkbox" name="enabled_methods[]" value="manual" id="method-manual" class="form-check-input">
                        <label for="method-manual" class="form-check-label">Manual</label>
                    </div>

                    <div class="form-check">
                        <input type="checkbox" name="enabled_methods[]" value="qr" id="method-qr" class="form-check-input">
                        <label for="method-qr" class="form-check-label">QR Code</label>
                    </div>

                    <div class="form-check">
                        <input type="checkbox" name="enabled_methods[]" value="kiosk" id="method-kiosk" class="form-check-input">
                        <label for="method-kiosk" class="form-check-label">Kiosk</label>
                    </div>

                    <div class="form-check">
                        <input type="checkbox"  name="enabled_methods[]" value="face_ai" id="method-face" class="form-check-input">
                        <label for="method-face" class="form-check-label">Face AI</label>
                    </div>

                    <div class="form-check">
                        <input type="checkbox"  name="enabled_methods[]" value="zoom" id="method-zoom" class="form-check-input">
                        <label for="method-zoom" class="form-check-label">Zoom</label>
                    </div>

                    <div class="form-check">
                        <input type="checkbox"  name="enabled_methods[]" value="youtube" id="method-youtube" class="form-check-input">
                        <label for="method-youtube" class="form-check-label">YouTube</label>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">{{ __('Online Config (Optional)') }}</label>
                    <input type="text" name="meeting_link" placeholder="Meeting/Stream Link" class="form-control">
                    <input type="text" name="meeting_id" placeholder="Meeting ID (Zoom)" class="form-control mt-2">
                    <input type="text" name="meeting_passcode" placeholder="Passcode (Zoom)" class="form-control mt-2">
                </div>

                <button type="submit" class="btn btn-success">{{ __('Save Attendance Event') }}</button>
            </form>
        </div>
    </div>

    <!-- Right Column: Instructions -->
    <div class="col-md-4">
        <div class="card shadow-sm p-4">
            <h6 class="fw-bold">{{ __('How to Setup an Attendance Event') }}</h6>
            <ul class="small mb-0">
                <li><strong>Select Event:</strong> Choose the main event this attendance session belongs to (e.g., Sunday Service, Bible Study).</li>
                <li><strong>Mode:</strong> 
                    <ul>
                        <li><em>Onsite</em> → members check in physically at church.</li>
                        <li><em>Online</em> → attendance via Zoom/YouTube link only.</li>
                        <li><em>Hybrid</em> → both onsite and online allowed.</li>
                    </ul>
                </li>
                <li><strong>Enabled Methods:</strong> Decide how members can check in:
                    <ul>
                        <li>Manual → Admin selects members manually.</li>
                        <li>QR Code → Members scan at entrance.</li>
                        <li>Kiosk → Tablet/laptop self check-in station.</li>
                        <li>Face AI → AI camera auto-check-in.</li>
                        <li>Zoom / YouTube → Auto-track online attendance.</li>
                    </ul>
                </li>
                <li><strong>Online Config:</strong> Enter Zoom or YouTube details (meeting link, ID, passcode) if the event is online/hybrid.</li>
                <li><strong>Save:</strong> Once saved, the event will appear in your Attendance Dashboard.</li>
            </ul>
        </div>
    </div>
</div>
@endsection
