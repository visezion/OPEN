@extends('layouts.main')

@section('page-title', $event->title . ' - ' . __('Event'))

@section('content')
<div class="card shadow-sm p-4">
    <h5>{{ $event->title }}</h5>
    <p class="text-muted">{{ $event->description }}</p>

    <div class="mb-3">
        <strong>{{ __('Date:') }}</strong> {{ $event->date }} <br>
        <strong>{{ __('Type:') }}</strong> {{ ucfirst($event->event_type) }}
    </div>
</div>
@endsection
