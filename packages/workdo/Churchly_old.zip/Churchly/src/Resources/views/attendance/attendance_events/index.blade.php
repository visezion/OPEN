
@extends('layouts.main')

@section('page-title', __('Attendance Events'))

@section('page-action')
    <a href="{{ route('churchly.attendance_events.create') }}" class="btn btn-sm btn-primary">
        <i class="ti ti-plus"></i> {{ __('New Attendance Event') }}
    </a>
@endsection

@section('content')
<div class="card shadow-sm p-3">
    <h5 class="mb-3">{{ __('All Attendance Events') }}</h5>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>{{ __('Event') }}</th>
                <th>{{ __('Date') }}</th>
                <th>{{ __('Mode') }}</th>
                <th>{{ __('Methods') }}</th>
                <th>{{ __('Actions') }}</th>
            </tr>
        </thead>
        <tbody>
            @forelse($attendanceEvents as $attendanceEvent)
                <tr>
                    <td>{{ $attendanceEvent->event->title ?? 'N/A' }}</td>
                    <td>{{ $attendanceEvent->event->date ?? '-' }}</td>
                    <td>{{ ucfirst($attendanceEvent->mode) }}</td>
                    <td>
                        {{ implode(', ', $attendanceEvent->enabled_methods ?? []) }}
                    </td>
                    <td>
                        <a href="{{ route('churchly.attendance_events.show', $attendanceEvent->id) }}" 
                           class="btn btn-sm btn-info">
                           {{ __('View') }}
                        </a>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="5" class="text-center text-muted">
                        {{ __('No attendance events found.') }}
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>
    {{ $attendanceEvents->links() }}
</div>
@endsection
