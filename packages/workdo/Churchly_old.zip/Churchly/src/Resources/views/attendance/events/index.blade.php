@extends('layouts.main')

@section('page-title', __('Events'))

@section('page-action')
    <a href="{{ route('churchly.events.create') }}" class="btn btn-sm btn-primary">
        <i class="ti ti-plus"></i> {{ __('Create Event') }}
    </a>
@endsection

@section('content')
<div class="card shadow-sm p-3">
    <h5 class="mb-3">{{ __('All Events') }}</h5>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>{{ __('Title') }}</th>
                <th>{{ __('Date') }}</th>
                <th>{{ __('Type') }}</th>
                <th>{{ __('Actions') }}</th>
            </tr>
        </thead>
        <tbody>
            @foreach($events as $event)
            <tr>
                <td>{{ $event->title }}</td>
                <td>{{ $event->date }}</td>
                <td>{{ ucfirst($event->event_type) }}</td>
                <td class="d-flex">
                    <a href="{{ route('churchly.events.show',$event->id) }}" class="btn btn-sm btn-info me-1">
                        <i class="ti ti-eye"></i> {{ __('View') }}
                    </a>

                    <form action="{{ route('churchly.events.destroy',$event->id) }}" 
                          method="POST" 
                          onsubmit="return confirm('{{ __('Are you sure you want to delete this event?') }}');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-sm btn-danger">
                            <i class="ti ti-trash"></i> {{ __('Delete') }}
                        </button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    {{ $events->links() }}
</div>
@endsection
