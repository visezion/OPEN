@extends('layouts.main')

@section('page-title')
    {{ __('Dashboard') }}
@endsection

@section('page-breadcrumb')
    {{ __('Church') }}
@endsection



@section('content')
    @if (session('status'))
        <div class="alert alert-success" role="alert">
            {{ session('status') }}
        </div>
    @endif

    <div class="row row-gap mb-4">
        <!-- Church Overview Card -->
        <div class="col-xl-6 col-12">
            <div class="dashboard-card">
                <img src="{{ asset('assets/images/layer.png') }}" class="dashboard-card-layer" alt="layer">
                <div class="card-inner">
                    <div class="card-content">
                        <h2>{{ Auth::user()->ActiveWorkspaceName() }}</h2>
                        <p>{{ __('Manage your church with ease through organized member directories, automated reminders, and real-time service analytics.') }}</p>
                    </div>
                    <div class="card-icon d-flex align-items-center justify-content-center">
                        <!-- SVG ICON -->
                        <!-- (SVG content remains unchanged for readability) -->
                    </div>
                </div>
            </div>
        </div>

        <!-- Mini Cards -->
        <div class="col-xl-6 col-12">
            <div class="row dashboard-wrp">
                @php
                    $stats = [
                        ['label' => 'Members', 'icon' => 'fas fa-users', 'count' => 12, 'color' => 'text-danger'],
                        ['label' => 'Weekly New Members', 'icon' => 'ti ti-users', 'count' => 22],
                        ['label' => 'Workers', 'icon' => 'ti ti-checks', 'count' => 243],
                        ['label' => 'Leaders', 'icon' => 'ti ti-circles', 'count' => 93],
                    ];
                @endphp

                @foreach ($stats as $stat)
                    <div class="col-sm-6 col-12">
                        <div class="dashboard-project-card">
                            <div class="card-inner d-flex justify-content-between">
                                <div class="card-content">
                                    <div class="theme-avtar bg-white">
                                        <i class="{{ $stat['icon'] }} {{ $stat['color'] ?? '' }}"></i>
                                    </div>
                                    <a href="#">
                                        <h3 class="mt-3 mb-0 {{ $stat['color'] ?? '' }}">{{ __($stat['label']) }}</h3>
                                    </a>
                                </div>
                                <h3 class="mb-0">{{ $stat['count'] }}</h3>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>

        <!-- Tasks & Project Chart -->
        <div class="col-xxl-5">
            <!-- Tasks Overview -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5>{{ __('Tasks Overview') }}</h5>
                </div>
                <div class="card-body p-2">
                    <div id="task-area-chart"></div>
                </div>
            </div>

            <!-- Project Status -->
            <div class="card">
                <div class="card-header">
                    <div class="float-end">
                        <a href="#" data-bs-toggle="tooltip" title="Referrals">
                            <i class=""></i>
                        </a>
                    </div>
                    <h5>{{ __('Project Status') }}</h5>
                </div>
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-sm-8">
                            <div id="projects-chart"></div>
                        </div>
                        <div class="col-sm-4">
                            <div class="col-6 mb-2 d-flex align-items-center">
                                <i class="f-10 lh-1 fas fa-circle text-danger"></i>
                                <span class="ms-2 text-sm">{{ __('On Going') }}</span>
                            </div>
                            <div class="col-6 mb-2 d-flex align-items-center">
                                <i class="f-10 lh-1 fas fa-circle text-warning"></i>
                                <span class="ms-2 text-sm">{{ __('On Hold') }}</span>
                            </div>
                            <div class="col-6 mb-2 d-flex align-items-center">
                                <i class="f-10 lh-1 fas fa-circle text-primary"></i>
                                <span class="ms-2 text-sm">{{ __('Finished') }}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
