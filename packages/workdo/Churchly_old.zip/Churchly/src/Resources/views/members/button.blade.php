  <span>
    @permission('church_member show')
    <div class="action-btn  me-2">
        <a href="{{ route('members.show', \Illuminate\Support\Facades\Crypt::encrypt( $member->id)) }}" class="btn btn-sm btn-info" data-bs-toggle="tooltip" title="{{ __('View') }}">
            <i class="ti ti-eye text-white"></i>
        </a>
    </div>
    @endpermission

    @permission('church_member edit')
    <div class="action-btn  me-2">
        <a href="{{ route('members.edit', \Illuminate\Support\Facades\Crypt::encrypt( $member->id)) }}" class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="{{ __('Edit') }}">
           
            <i class="ti ti-pencil text-white"></i>
        </a>
    </div>
    @endpermission

    @permission('church_member delete')
        {!! Form::open(['method' => 'DELETE', 'route' => ['members.destroy', $member->id], 'style'=>'display:inline']) !!}
            <button type="submit" class="btn btn-sm btn-danger show_confirm" data-bs-toggle="tooltip" title="{{ __('Delete') }}">
                <i class="ti ti-trash"></i>
            </button>
        {!! Form::close() !!}
    @endpermission
</span>
