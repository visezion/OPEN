<?php

namespace Workdo\Churchly\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Workdo\Churchly\Entities\Event;

class EventController extends Controller
{
    public function index()
    {
        $events = Event::inWorkspace()
            ->latest()
            ->paginate(20);

        return view('churchly::attendance.events.index', compact('events'));
    }

    public function create()
    {
        return view('churchly::attendance.events.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:191',
            'date' => 'required|date',
            'event_type' => 'required|string',
        ]);

        Event::create([
            'workspace_id' => getActiveWorkSpace(),
            'created_by'   => Auth::id(),
            'title'        => $request->title,
            'description'  => $request->description,
            'date'         => $request->date,
            'start_time'   => $request->start_time,
            'end_time'     => $request->end_time,
            'event_type'   => $request->event_type,
        ]);

        return redirect()
            ->route('churchly.events.index')
            ->with('success', __('Event created successfully.'));
    }

    public function show($id)
    {
        $event = Event::inWorkspace()->findOrFail($id);

        return view('churchly::attendance.events.show', compact('event'));
    }

    public function destroy($id)
    {
        $event = Event::inWorkspace()->findOrFail($id);
        $event->delete();

        return back()->with('success', __('Event deleted successfully.'));
    }
}
