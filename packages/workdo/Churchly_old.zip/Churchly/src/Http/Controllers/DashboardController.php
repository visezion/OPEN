<?php

namespace Workdo\Churchly\Http\Controllers;

use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;


use Illuminate\Support\Facades\DB;
use Workdo\Taskly\Entities\ClientProject;
use Workdo\Taskly\Entities\Stage;
use Workdo\Taskly\Entities\Task;
use Workdo\Taskly\Entities\UserProject;
use App\Models\Notification;
use App\Models\User;
class DashboardController extends Controller
{
    public function index()
    {
        if(Auth::check())
        {
         
            if (Auth::user()->isAbleTo('churchly dashboard manage'))
            {
             
                return view('churchly::dashboard.index');

            }
            else
            {
                return redirect()->back()->with('error', __('Permission Denied.'));
            }
        }
        else
        {
            return redirect()->route('login');
        }

    }



}


        