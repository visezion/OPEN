<?php

namespace Workdo\Churchly\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Workdo\Churchly\Entities\AttendanceEvent;
use Workdo\Churchly\Entities\Event;

class AttendanceEventController extends Controller
{
    public function index()
    {
        $attendanceEvents = AttendanceEvent::with('event')
            ->where('workspace_id', getActiveWorkSpace())
            ->latest()
            ->paginate(20);

        return view('churchly::attendance.attendance_events.index', compact('attendanceEvents'));
    }

    public function create()
    {
        $events = Event::all();
        return view('churchly::attendance.attendance_events.create', compact('events'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'event_id' => 'required|exists:events,id',
            'mode' => 'required|string|in:onsite,online,hybrid',
        ]);

        AttendanceEvent::create([
            'workspace_id' => getActiveWorkSpace(),
            'branch_id' => $request->branch_id,
            'department_id' => $request->department_id,
            'event_id' => $request->event_id,
            'mode' => $request->mode,
            'enabled_methods' => $request->enabled_methods ?? [],
            'online_platform' => $request->online_platform,
            'meeting_link' => $request->meeting_link,
            'meeting_id' => $request->meeting_id,
            'meeting_passcode' => $request->meeting_passcode,
            'auto_log_attendance' => $request->auto_log_attendance ?? false,
            'created_by' => Auth::id(),
        ]);

        return redirect()->route('churchly.attendance_events.index')
            ->with('success', __('Attendance event created successfully.'));
    }

    public function show($id)
    {
        $attendanceEvent = AttendanceEvent::with('event','records')->findOrFail($id);
        return view('churchly::attendance.attendance_events.show', compact('attendanceEvent'));
    }
}
