<?php

namespace Workdo\Churchly\Entities;

use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    protected $table = 'events';

    protected $fillable = [
        'workspace_id',
        'created_by',
        'title',
        'description',
        'date',
        'start_time',
        'end_time',
        'event_type',
    ];

    /**
     * Scope events to the active workspace
     */
    public function scopeInWorkspace($query)
    {
        return $query->where('workspace_id', getActiveWorkSpace());
    }

    /**
     * Relationship: creator of the event
     */
    public function creator()
    {
        return $this->belongsTo(\App\Models\User::class, 'created_by');
    }

    /**
     * Relationship: all attendance sessions linked to this event
     */
    public function attendanceEvents()
    {
        return $this->hasMany(AttendanceEvent::class, 'event_id');
    }
}
