<?php

namespace Workdo\Churchly\Entities;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ChurchMember extends Model
{
    use HasFactory;

    protected $table = 'church_members';

    protected $fillable = [
        'user_id',
        'name',
        'profile_photo',          // ✅ added
        'dob',
        'gender',
        'phone',
        'address',
        'email',
        'password',
        'member_id',
        'branch_id',
        'role_id',                // ✅ added (for linking roles)
        'church_doj',
        'documents',
        'membership_status',      // ✅ added
        'family_id',              // ✅ added
        'spouse_id',              // ✅ added
        'emergency_contact',      // ✅ added
        'emergency_phone',        // ✅ added
        'is_active',
        'workspace',
        'created_by',
    ];

    protected $casts = [
        'dob' => 'date',
        'church_doj' => 'date',
        'is_active' => 'boolean',
    ];

    protected $hidden = [
        'password',
    ];

    /*
    |--------------------------------------------------------------------------
    | Relationships
    |--------------------------------------------------------------------------
    */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function branch()
    {
        return $this->belongsTo(ChurchBranch::class, 'branch_id');
    }

    public function departments()
    {
        return $this->belongsToMany(
            ChurchDepartment::class,
            'church_member_department',
            'church_member_id',
            'department_id'
        )->withPivot('designation_id')->withTimestamps();
    }

    public function customValues()
    {
        return $this->hasMany(ChurchMemberCustomValue::class, 'member_id');
    }

    public function designation()
    {
        return $this->belongsTo(ChurchDesignation::class, 'designation_id');
    }

    public function family()
    {
        return $this->belongsTo(ChurchMember::class, 'family_id');
    }

    public function spouse()
    {
        return $this->belongsTo(ChurchMember::class, 'spouse_id');
    }
    public function activities()
    {
        return $this->hasMany(ChurchActivityLog::class, 'member_id');
    }

    public function progress()
    {
        return $this->hasMany(DiscipleshipMemberProgress::class, 'member_id');
    }
    
    public function discipleshipReviews()
    {
        return $this->hasMany(DiscipleshipMemberProgress::class, 'reviewed_by');
    }

    public function attendanceRecords()
    {
        return $this->hasMany(AttendanceRecord::class, 'member_id');
    }
    /*
    |--------------------------------------------------------------------------
    | Accessors
    |--------------------------------------------------------------------------
    */
    public function getFormattedMemberIdAttribute()
    {
        $company_settings = getCompanyAllSetting();
        $member_prefix = $company_settings['member_prefix'] ?? '#MBR';
        return $member_prefix . sprintf("%05d", $this->id);
    }

    public function getFormattedDobAttribute()
    {
        return $this->dob ? $this->dob->format('d M Y') : '-';
    }

    public function getFormattedChurchDojAttribute()
    {
        return $this->church_doj ? $this->church_doj->format('d M Y') : '-';
    }

    /*
    |--------------------------------------------------------------------------
    | Scopes
    |--------------------------------------------------------------------------
    */
    public function scopeForWorkspace($query, $workspaceId = null)
    {
        $workspaceId = $workspaceId ?? getActiveWorkSpace();
        return $query->where('workspace', $workspaceId);
    }

    public function scopeCreatedBy($query, $creatorId = null)
    {
        $creatorId = $creatorId ?? creatorId();
        return $query->where('created_by', $creatorId);
    }

    /*
    |--------------------------------------------------------------------------
    | Utilities
    |--------------------------------------------------------------------------
    */
    public static function generateMemberId()
    {
        $date = now()->format('Ymd');
        $countToday = self::whereDate('created_at', today())->count() + 1;
        return 'MBR-' . $date . '-' . str_pad($countToday, 4, '0', STR_PAD_LEFT);
    }
}
