<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('attendance_events', function (Blueprint $table) {
        $table->id();
        $table->unsignedBigInteger('workspace_id');
        $table->unsignedBigInteger('branch_id')->nullable();
        $table->unsignedBigInteger('department_id')->nullable();
        $table->unsignedBigInteger('event_id'); // links to events table
        $table->enum('mode', ['onsite', 'online', 'hybrid'])->default('onsite');
        $table->json('enabled_methods')->nullable(); 
        // ["manual","qr","kiosk","face_ai","zoom","youtube"]
        $table->string('online_platform')->nullable(); // zoom, youtube, facebook, custom
        $table->string('meeting_link')->nullable();
        $table->string('meeting_id')->nullable(); // for Zoom
        $table->string('meeting_passcode')->nullable();
        $table->boolean('auto_log_attendance')->default(false);
        $table->string('qr_code')->nullable();
        $table->boolean('face_ai_enabled')->default(false);
        $table->unsignedBigInteger('created_by');
        $table->timestamps();

        $table->foreign('event_id')->references('id')->on('events')->onDelete('cascade');
    });

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('attendance_events');
    }
};
