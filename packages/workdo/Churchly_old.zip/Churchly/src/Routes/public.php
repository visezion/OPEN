<?php 

use Illuminate\Support\Facades\Route;
use Workdo\Churchly\Http\Controllers\ChurchMemberSelfServiceController;

Route::group(['prefix' => '{workspace}'], function () {
    Route::get('register', [ChurchMemberSelfServiceController::class, 'showForm'])->name('churchly.self.register');
    Route::post('register', [ChurchMemberSelfServiceController::class, 'store'])->name('churchly.self.register.store');
});
