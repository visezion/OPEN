<?php

namespace Workdo\Account\Events;

use Illuminate\Queue\SerializesModels;

class UpdateBankTransfer
{
    use SerializesModels;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public $request;
    public $transfer;

    public function __construct($request ,$transfer)
    {
        $this->request = $request;
        $this->transfer = $transfer;
    }
}
